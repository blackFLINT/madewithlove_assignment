<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of selp
 *
 * @author kwaku.afreh-nuamah
 */
require __DIR__ . '/vendor/autoload.php';

use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Promise;
use GuzzleHttp\Exception\ClientException;
use Psr\Http\Message\ResponseInterface;
use GuzzleHttp\Pool;

class Weather {

    private $client;
    private $url = 'https://api.darksky.net/forecast/123c76f28120f3fb94ef9974ddd6770b/';
             //'8f69b6a45e26fe5c6552aac2375ab060/';
            //'123c76f28120f3fb94ef9974ddd6770b/' gcnet;
    //. 'c9c1742e945e6781b7e07a338939a86a/' gmail;
    private $promises = [];
    private $weathertype;
    private $longitude;
    private $latitude;
    private $results = [];
    private $time;
    private $requests;
    private $daily = [];

    public function __construct() {
        $this->client = new Client(['http_errors' => false, 'headers' => ['Content-Type' => 'application/json'], 'timeout' => 0, 'verify' => false,
            'query' => ['exclude' => 'hourly,currently,minutely,alerts,flags']]);
    }

    /**
     * Function to connect to Loop through and compile urls for DarkSky API connection
     * @return array
     */
    private function setRequests($option = 'Observed', $total = 30, $yield_long = "5.542495332105687", $yield_lat = "-0.2381454347332692", $start_date = null) {
        $n = 0;
        if (empty($start_date)) {
            $date = date('Y-m-d');
        } else {
            $date = $start_date;
        }
        switch ($option) {
            case 'Observed':

                $daily = new DateTime($date);

                $this->time = $daily->format('Y-m-d H:i:s');

                $urltime = strtotime($this->time);
                $url = $this->url . "$yield_lat,$yield_long,$urltime";
                yield new Request('GET', $url);
                for ($n = 1; $n < $total; $n++) {
                    $this->time = null;
                    $daily = new DateTime($date);
                    $daily->sub(new DateInterval('P' . $n . 'D'));
                    $this->time = $daily->format('Y-m-d H:i:s');
                    $urltime = strtotime($this->time);
                    $url = $this->url . "$yield_lat,$yield_long,$urltime";
//                            $this->promises[] = $this->client->sendAsync($url);
                    yield new Request('GET', $url);
                }
                break;
            case 'Forecast':
                $daily = new DateTime($date);

                $this->time = $daily->format('Y-m-d H:i:s');
                $urltime = strtotime($this->time);
                $url = $this->url . "$yield_lat,$yield_long,$urltime";
                yield new Request('GET', $url);
                for ($n = 1; $n <= $total; $n++) {
                    $this->time = null;
                    $daily = new DateTime($date);
                    $daily->add(new DateInterval('P' . $n . 'D'));
                    $this->time = $daily->format('Y-m-d H:i:s');
                    $urltime = strtotime($this->time);
                    $url = $this->url . "$yield_lat,$yield_long,$urltime";
//                            $this->promises[] = $this->client->sendAsync($url);
                    yield new Request('GET', $url);
                }

                break;
        }
    }

    /**
     * Function to connect to Dark SKY API
     * @return json 
     */
    public function api_connector($weatheroption = null, $long = null, $lat = null, $startdate = null, $enddate = null) {

        if (!empty($weatheroption) && !empty($long) && !empty($lat)) {





//            try {
//                if()
            switch ($weatheroption) {
                case 'Observed':
                    $requests = $this->setRequests('Observed', 30, $long, $lat);
                    
                    break;
                case 'Forecast':
                    $checksdate = $this->validateDate($startdate);
                    $checkedate = $this->validateDate($enddate);
                    if (!$checksdate) {
                        $date_array = array('Status' => 'FAIL', 'Message' => 'Invalid Start Date Entered');

                        echo json_encode($date_array);
                        return;
                    } elseif (!$checkedate) {
                        $date_array = array('Status' => 'FAIL', 'Message' => 'Invalid End Date Entered');

                        echo json_encode($date_array);
                        return;
                    }
                    $process_startdt = date('Y-m-d', strtotime($startdate));
                    $process_enddt = date('Y-m-d', strtotime($enddate));
                    $total_days = $this->dateDifference($process_startdt, $process_enddt);

                    if (strtotime($process_startdt) > strtotime($process_enddt)) {
                        $msg_array = array('Status' => 'FAIL', 'Message' => 'Startdate cannot be more than Enddate');
                        echo json_encode($msg_array);
                        return;
                    }
                    $requests = $this->setRequests('Forecast', $total_days, $long, $lat,$startdate);
            }

//                        $response = Promise\settle($this->promises)->wait(true);
//                        break;
//             $response = Promise\settle($this->promises)->wait();
            $pool = new Pool($this->client, $requests, [
                'concurrency' => 5,
                'fulfilled' => function (Response $response, $index) {
                    // this is delivered each successful response
                    $this->results = json_decode($response->getBody()->getContents(),true);
                    $dateproc = $this->results['daily']['data'][0]['time'];
                    if(!empty($dateproc)){
                      $timeindex = date('Y-m-d',$dateproc); 
                    $this->daily[$timeindex] = $this->results['daily']['data'][0];
                    }
//               $this->daily[] = $this->results;
//                    return $this->results;exit;
                },
                'rejected' => function (RequestException $reason, $index) {
                    // this is delivered each failed request
                    echo GuzzleHttp\Psr7\str($reason->getResponse());
                },
            ]);
            // Initiate the transfers and create a promise
            $promise = $pool->promise();

// Force the pool of requests to complete.
            $promise->wait();
            if(!empty($this->daily)){
            $msg_array = array('Status' => 'SUCC', 'Data' => $this->daily);
            }else{
               $msg_array = array('Status' => 'FAIL', 'Message' => 'Error Fetching Data from Dark Sky'); 
            }
                        echo json_encode($msg_array);
                        return;
            
        } else {
            echo json_encode(array('Status' => 'FAIL'));
        }
    }

    /**
     * Function to validate dates
     * @return boolean
     */
    function validateDate($myDateString) {
        return (bool) strtotime($myDateString);
    }

    /**
     * Function to calculate date differences
     * @return string on success or boolean on failure
     */
    function dateDifference($date_1, $date_2, $differenceFormat = '%a') {
        $datetime1 = date_create($date_1);
        $datetime2 = date_create($date_2);

        $interval = date_diff($datetime1, $datetime2);

        return $interval->format($differenceFormat);
    }

}

if (!empty($_POST['weatheroption']) && !empty($_POST['long']) && !empty($_POST['lat']) && empty($_POST['startdate']) && empty($_POST['enddate'])) {

    $weather = new Weather();
    $result = $weather->api_connector($_POST['weatheroption'], $_POST['long'], $_POST['lat']);

    return $result;
} elseif (!empty($_POST['weatheroption']) && !empty($_POST['long']) && !empty($_POST['lat']) && !empty($_POST['startdate']) && !empty($_POST['enddate'])) {

    $weather = new Weather();
    $result = $weather->api_connector($_POST['weatheroption'], $_POST['long'], $_POST['lat'], $_POST['startdate'], $_POST['enddate']);

    return $result;
}