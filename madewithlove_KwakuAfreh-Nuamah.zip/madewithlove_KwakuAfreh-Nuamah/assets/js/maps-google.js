$(document).ready(function(){
        $("#map").googleMap({}),
            $("#map").addMarker({coords:[48.895651,2.290569],
                title:"Marker n°1",text:"ate velit laborum."}),
            $("#map").addMarker({coords:[48.869439,2.308664],
                title:"Marker n°2",text:"giat nulla pariatur."}),
            $("#map").addMarker({coords:[48.888846,2.198674],
                title:"Marker n°3",text:"Denderit im id est laborum."});
        var a=document.head,b=new MutationObserver(function(a){
            for(var c=0;a[c];++c)
                if("SCRIPT"==a[c].addedNodes[0].nodeName&&a[c].addedNodes[0].src.match(/\/AuthenticationService.Authenticate?/g)){
                var d=a[c].addedNodes[0].src.match(/[?&]callback=.*[&$]/g);
                if(d){d="&"==d[0][d[0].length-1]?d[0].substring(10,d[0].length-1):d[0].substring(10);
                    var e=d.split("."),f=e[0],g=e[1];window[f][g]=null
                }
                b.disconnect()
            }
        }),
            c={attributes:!0,childList:!0,characterData:!0};b.observe(a,c)
    });
