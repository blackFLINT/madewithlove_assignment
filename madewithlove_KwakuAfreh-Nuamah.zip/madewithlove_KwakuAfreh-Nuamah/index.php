
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Made With Love | Weather Forecast/Observations</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="author" content="Prakasam Mathaiyan">
        <meta name="description" content="">
        <!--[if IE]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script type="text/javascript" src="assets/plugins/lib/modernizr.js"></script>
        <link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="assets/css/main.css">
        <link rel="stylesheet" type="text/css" href="assets/css/style-default.css">
        <link rel="stylesheet" type="text/css" href="assets/plugins/tagsinput/bootstrap-tagsinput.css">
    </head>

    <body>
        <div class="wrapper has-footer">
            <header class="header-top navbar fixed-top" style="background-color:#ccc">
                <div class="top-bar">   <!-- START: Responsive Search -->
                    <div class="container">
                        <div class="main-search">
                            <div class="input-wrap">

                                <a href="#"><i class="sli-magnifier"></i></a>
                            </div>
                            <span class="close-search search-toggle"><i class="ti-close"></i></span>
                        </div>
                    </div>
                </div>

                <div class="collapse navbar-collapse" id="headerNavbarCollapse">
                    <!-- <ul class="nav navbar-nav">
                         <li class="hidden-xs" style="padding-top: 7px">
                          
                         </li>
                     </ul>-->



                </div>
            </header>  <!-- END: Header -->

            <div class="main-container">    <!-- START: Main Container -->

                <div class="page-header">

                    <!--<ol class="breadcrumb">
                        <li><a href="index-2.html">Home</a></li>
                        <li><a href="index-2.html">Maps</a></li>
                        <li class="active">Map Tracker</li>
                    </ol>-->
                </div>

                <div class="content-wrap view-inbox">  <!--START: Content Wrap-->
                    <div class="row">
                        <div class="col-md-3">
                            <div class="input-group">
                                <input type="text" class="form-control" id="txtlocation" placeholder="Search Location (Place)...">
                                <span class="input-group-btn"> <!--<button  onclick="my_click()" class="btn btn-secondary" type="button"><i class="fa fa-search"></i></button> --></span>
                            </div><!-- /input-group -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-7">
                            <div class="panel">
                                <div class="panel-body">
                                    <div id="map" style="height: 400px;"></div>
                                </div>

                            </div>
                        </div>

                        <div class="col-md-5">
                            <div class="col-md-12" id="item-info1">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">ADDRESSES</h3>
                                        <div class="tools">
                                            <a class="btn-link collapses panel-collapse" href="javascript:;"></a>
                                            <a class="btn-link reload" href="javascript:;"><i class="ti-reload"></i></a>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <form class="form-horizontal" action="#" method="post">
                                            <!--     <div class="form-group">
                                                     <label for="inputUserName" class="col-sm-4 control-label">Acccount #</label>
                                                     <div class="col-sm-8">
                                                         <input type="text" class="form-control" id="inputUserName" required="required" placeholder="Account Number">
                                                     </div>
                                                 </div>
                                                 <div class="form-group">
                                                     <label for="inputEmail3" class="col-sm-4 control-label">Account Name</label>
                                                     <div class="col-sm-8">
                                                         <input type="text" class="form-control" id="inputEmail3" placeholder="Account Name">
                                                     </div>
                                                 </div>
                                                  <div class="form-group">
                                                     <label for="inputEmail3" class="col-sm-4 control-label">Account Type</label>
                                                     <div class="col-sm-8">
                                                         <input type="text" class="form-control" id="inputEmail3" placeholder="Account Type">
                                                     </div>
                                                 </div>
                                                  <div class="form-group">
                                                     <label for="inputEmail3" class="col-sm-4 control-label">Date of Birth</label>
                                                     <div class="col-sm-8">
                                                         <input type="text" class="form-control" id="inputEmail3" placeholder="Date of Birth">
                                                     </div>
                                                 </div>
                                                  <div class="form-group">
                                                     <label for="inputEmail3" class="col-sm-4 control-label">Occupation</label>
                                                     <div class="col-sm-8">
                                                         <input type="email" class="form-control" id="inputEmail3" placeholder="Occupation">
                                                     </div>
                                                 </div>
                                                  <div class="form-group">
                                                     <label for="inputEmail3" class="col-sm-4 control-label">Postal Address</label>
                                                     <div class="col-sm-8">
                                                         <input type="text" class="form-control" id="PAddress" placeholder="Postal Address">
                                                     </div>
                                                 </div>-->
                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Street Address</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="SAddress" placeholder="Street Address">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Latitude / Longitude</label>
                                                <div class="col-sm-4">
                                                    <input type="text" class="form-control" id="Latitude" placeholder="Latitude">
                                                </div>
                                                <div class="col-sm-4">
                                                    <input type="text" class="form-control" id="Longitude" placeholder="Longitude">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Surburb / District</label>
                                                <div class="col-sm-4">
                                                    <input type="text" class="form-control" id="Surburb" placeholder="Surburb">
                                                </div>
                                                <div class="col-sm-4">
                                                    <input type="text" class="form-control" id="City" placeholder="City">
                                                </div>
                                            </div>





                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Region</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="Region" placeholder="Region">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Weather Option</label>
                                                <div class="col-sm-8">
                                                    <select id="weatheropinput" name="weatheropinput">
                                                        <option value="" selected="selected">Select Option ...</option>
                                                        <option value="Observed">Observed(30 Days)</option>
                                                        <option value="Forecast">Forecast</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group" id="weatherdate">
                                                <label for="inputEmail3" class="col-sm-4 control-label">Date</label>
                                                <div class="col-sm-4">
                                                    <input type="date" class="form-control weatherdate" disabled="true" id="startdate" placeholder="Start Date">
                                                </div>
                                                <div class="col-sm-4">
                                                    <input type="date" class="form-control weatherdate" disabled="true" id="enddate" placeholder="End Date">
                                                </div>
                                            </div>
                                            <!-- <div class="form-group">
                                                   <label for="inputEmail3" class="col-sm-4 control-label">Image Upload</label>
                                                 <div class="col-sm-8">
                                                     <input type="file">
                                                 </div>
                                                
                                             </div>
                                            -->
                                            <div class="form-group">
                                                <label for="inputEmail3" class="col-sm-4 control-label"></label>
                                                <div class="col-sm-4">
                                                    <button type="reset" class="btn btn-default btn-warning">Reset</button>
                                                </div>

                                                <div class="col-sm-4">
                                                    <button type="submit" id="mbtnclick" formaction="javascript:void(0)" class="btn btn-default btn-info"> Submit</button>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-md-4">
                            <div class="col-md-12" id="item-info" style="display: none;">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">NOTIFICATIONS</h3>
                                        <div class="tools">
                                            <a class="btn-link collapses panel-collapse" href="javascript:;"></a>
                                            <a class="btn-link reload" href="javascript:;"><i class="ti-reload"></i></a>
                                        </div>
                                    </div>
                                    <div class="panel-body">
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr style="background-color: #A3CCFF;">
                                                    <th colspan="3"></th>

                                                </tr>
                                            </thead>
                                            <tbody id="trackinfo">
                                    
                                            </tbody>
                                        </table>
                                        <div class="col-sm-12">
                                            <form class="form-horizontal" action="#" method="post">

                                                <span><button type="submit" style="float: left" formaction="javascript:void(0)"  class="btn btn-default btn-info bkclick"> Back</button><a  style="float: right" href='index.php' id='bkclick' class='btn btn-default btn-info'> Refresh Page</a></span>
                                            </form>
                                        </div>  
                                    </div>

                                </div>
                            </div>

                        </div>

                        <div class="col-md-4">
                            <div class="col-md-12" id="weather-info" style="display: none;">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">WEATHER</h3>
                                        <div class="tools">
                                            <a class="btn-link collapses panel-collapse" href="javascript:;"></a>
                                            <a class="btn-link reload" href="javascript"><i class="ti-reload"></i></a>
                                        </div>
                                    </div>
                                    
                                    <div class="panel-body" style="color:#000;height: 400px;overflow: scroll;">
                                     
                                        <!--<ul class="list-reset  fadein-stagger"  ></ul>-->
                                        <table class="table table-striped fadein-stagger" style="color:#000;overflow: auto;" >
                                            <thead style="color:#000;" ><tr >
                                                    <th colspan="3"></th>

                                                </tr></thead>
                                            <tbody id="forecast" class="forecast" >
                                                
                                                <tr >
                                                    <td colspan="3"></td>

                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                        <div class="col-sm-12">
                                            <form class="form-horizontal" action="#" method="post">

                                                <span><button type="submit" style="float: left" formaction="javascript:void(0)" class="btn btn-default btn-info bkclick"> Back</button><a  style="float: right" href='index.php' id='bkclick' class='btn btn-default btn-info'> Refresh Page</a></span>
                                            </form>
                                          
                                        </div>  
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>  <!--END: Content Wrap-->

            </div>  <!-- END: Main Container -->

            <footer class="footer" align="center"> <!-- START: Footer -->
                &copy; <?php echo date('Y'); ?> <b><a href="https://darksky.net/poweredby/">Powered by Dark Sky</a></b>
            </footer>   <!-- END: Footer -->

        </div>  <!-- END: wrapper -->
        <div class="modal_custom"><!-- Place at bottom of page --></div>
        <!--  <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBkV4Yn4LxCaVECMWyMFi-robcivGseiI&callback=initMap">
        </script>-->
        <!--<script type="text/javascript" src="assets/plugins/lib/jquery-2.2.4.min.js"></script>
        <script type="text/javascript" src="assets/plugins/lib/jquery-ui.min.js"></script>
        <script type="text/javascript" src="assets/plugins/bootstrap/bootstrap.min.js"></script>
        <script type="text/javascript" src="assets/plugins/lib/plugins.js"></script>
        <script type="text/javascript" src="assets/plugins/lib/jquery.googlemap.js"></script>
        <script type="text/javascript" src="assets/plugins/tagsinput/bootstrap-tagsinput.min.js"></script>
            <script type="text/javascript" src="assets/plugins/typeahead/bloodhound.min.js"></script>
            <script type="text/javascript" src="assets/plugins/typeahead/typeahead.bundle.min.js"></script>
        
            <script type="text/javascript" src="assets/js/app.base.js"></script>
            <script type="text/javascript" src="assets/js/cmp-taginput.js"></script>-->

        <script type="text/javascript" src="assets/plugins/lib/jquery-2.2.4.min.js"></script>
        <script type="text/javascript" src="assets/plugins/lib/jquery-ui.min.js"></script>
        <script type="text/javascript" src="assets/plugins/bootstrap/bootstrap.min.js"></script>
        <script type="text/javascript" src="assets/plugins/lib/plugins.js"></script>
        <script type="text/javascript" src="assets/plugins/lib/jquery.googlemap.js"></script>
        <script type="text/javascript" src="assets/js/app.base.js"></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/skycons/1396634940/skycons.min.js'></script>
    </body>



</html>


<script>
    $body = $("body");
    $(document).bind("ajaxSend", function () {
        $body.addClass("loading");
    }).bind("ajaxComplete", function () {
        $body.removeClass("loading");
    });

    $("#weatheropinput").change(function () {
        var value = $(this).val();


        if (value == "Forecast") {
            $(".weatherdate").prop('disabled', false);
        } else if (value == "Observed") {
            $(".weatherdate").prop('disabled', true);
        } else if (value == "") {
            $(".weatherdate").prop('disabled', true);
        }
    });

    $(".bkclick").click(function () {

        $("#trackinfo").html("");
        $("#forecast").html("");
        $("#item-info").hide();
        $("#weather-info").hide();
        $("#item-info1").show();


    });

    $("#mbtnclick").click(function () {

        var weatherop = $("#weatheropinput").val();
        var longval = $("#Longitude").val();
        var latval = $("#Latitude").val();
        var startdt = $("#startdate").val();
        var enddt = $("#enddate").val();

        $("#trackinfo").html("");
        if (latval == '') {
            $("#item-info1").hide();
            $("#item-info").show();
            $("#trackinfo").html("");
            $("#trackinfo").append("<tr><td colspan='3'><span style='color:#FF0000;text-align:center'>Missing location latitude. Check and try again.</span></td></tr>");
//     $("#trackinfo").append("<tr><td colspan='3'><button type='submit' id='bkclick' formaction='javascript:window.void(0)' class='btn btn-default btn-info'> Back</button></td></tr>")
            $("#Latitude").focus();
            return false;
        } else if (longval == '') {
            $("#item-info1").hide();
            $("#item-info").show();
            $("#trackinfo").html("");
            $("#trackinfo").append("<tr><td colspan='3'><span style='color:#FF0000;text-align:center'>Missing location longitude.  Check and try again.</span></td></tr>");
            $("#Longitude").focus();
            return false;
        } else if (weatherop == '') {
            $("#item-info1").hide();
            $("#item-info").show();
            $("#trackinfo").html("");
            $("#trackinfo").append("<tr><td colspan='3'><span style='color:#FF0000;margin-left:15px'>Missing location weather option.  Check and try again.</span></td></tr>");
            $("#weatheropinput").focus();
            return false;
        }

        if ((weatherop == "Forecast") && (startdt == "") && (enddt == "")) {
            $("#item-info1").hide();
            $("#item-info").show();
            $("#trackinfo").html("");
            $("#trackinfo").append("<tr><td colspan='3'><span style='color:#FF0000;margin-left:50px'>Missing Sart Date/End Date.  Check and try again.</span></td></tr>");

            $("#startdate").focus();
            return false;
        }
        $("#mbtnclick").prop('disabled', true);

        $.ajax({

            method: "POST",
            url: "selp.php",
            data: {"weatheroption": weatherop, "long": longval, "lat": latval, "startdate": startdt, "enddate": enddt},
            dataType: "json",
            complete: function (xhr) {
                 console.log("done");
                $("#mbtnclick").attr('disabled', false);
               
          var results =    JSON.parse(xhr.responseText);
           var data =results.Data;
           if(results.Status == 'SUCC'){
               var objlength = Object.values(data).length; 
               
               if(objlength => 1){
                   
               $("#item-info").hide();
               $("#item-info1").hide();
            $("#weather-info").show();
            $("#forecast").html("<tr ><td colspan='3'></td></tr>");
               $.each( data, function( key, value ) {
                   
             if (value) {
  
               // Append Markup for each Forecast of the given date period
			$(".forecast tr:last").after(
				'<tr class="shade-'+ value.icon +'"><div class="card-container"><div><div class="front card"><td colspan="3"><div>' +
					"<div class='graphic'><canvas class=" + value.icon + "></canvas></div>" +
					"<div><b>Date</b>: " + key + "</div>" +
					"<div><b>Mix Temperature</b>: " + value.temperatureMin + "</div>" +
					"<div><b>Max Temperature.</b>: " + value.temperatureMax + "</div>" +
					"<div><b>Humidity</b>: " + value.humidity + "</div>" +
					'<p class="summary">' + value.summary + '</p>' +
					'</div></div><div class="back card">' +
					'<div class="hourly' + ' ' + key + '"><b>24hr Forecast</b><ul class="list-reset"></ul></div></div></div></div></td></tr>'
			);
            }else{
                $("#item-info1").hide();
            $("#item-info").show();
            $("#trackinfo").html("");
            $("#forecast").html("");
        $("#weather-info").hide();
            $("#trackinfo").append("<tr><td colspan='3'><span style='color:#FF0000;margin-left:50px'>Error. No data to display</span></td></tr>");
 
            }
            	skycons(); // inject skycons for each forecast
		staggerFade(); // fade-in forecast cards in a stagger-esque fashion
});
}  
}else if(results.Status == 'FAIL'){
  $("#item-info1").hide();
            $("#item-info").show();
            $("#trackinfo").html("");
            $("#forecast").html("");
        $("#weather-info").hide();
            $("#trackinfo").append("<tr><td colspan='3'><span style='color:#FF0000;margin-left:50px'>"+results.Message +"</span></td></tr>");
 
}
                return false;
            }
        });
        $("#mbtnclick").attr('disabled', false);
    });
    var map;
    var markers = [];
    var autocomplete;
    var place;
    var streetadd;
    var newsadd;


    function initMap() {
        var Ghana = {lat: 5.57678, lng: -0.27416};
        var geocoder = new google.maps.Geocoder();

        function geocodePosition(pos) {
            geocoder.geocode({
                latLng: pos
            }, function (responses) {
                //alert(pos);
                // console.log('You clicked on: ' + pos);

                $("#Latitude").val(pos.lat());
                $("#Longitude").val(pos.lng());
                // var latlng = {lat: parseFloat(latlngStr[0]), lng: parseFloat(latlngStr[1])};
                if (responses && responses.length > 0) {

                    $.each(responses[0].address_components, function (i, address_component) {
                        streetadd = responses[0].formatted_address;
                        newsadd = streetadd.split(",");
                        //console.log('You clicked on: ' + responses[0].address_components.types[0]); 

                        $("#SAddress").val(newsadd[0]);

                        if (address_component.types[0] == "locality") {
                            console.log(i + ": Third:" + address_component.long_name);
                            $("#City").val(address_component.long_name);
                        }
                        if (address_component.types[0] == "administrative_area_level_2") {
                            console.log(i + ": Surburb :" + address_component.long_name);
                            $("#Surburb").val(address_component.long_name);
                        }

                        if (address_component.types[0] == "administrative_area_level_1") {
                            console.log("Region:" + address_component.long_name);
                            $("#Region").val(address_component.long_name);
                        }
                        if (address_component.types[0] == "post_box") {
                            console.log("PAddress:" + address_component.long_name);
                            $("#PAddress").val(address_component.long_name);
                        }
                    });
                    //   updateMarkerAddress(responses[0].formatted_address);
                } else {
                    //  updateMarkerAddress('Cannot determine address at this location.');
                }
            });
        }
        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 10,
            center: Ghana,
            mapTypeId: google.maps.MapTypeId.ROADMAP //'terrain'
        });

        // This event listener will call addMarker() when the map is clicked.
        map.addListener('click', function (event) {
            clearMarkers();
            addMarker(event.latLng);
            geocodePosition(event.latLng);

        });

        // Location search and autocomplete
        var input = document.getElementById('txtlocation');

        autocomplete = new google.maps.places.SearchBox(input);
//                                        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
        autocomplete.bindTo('bounds', map);

        autocomplete.addListener('places_changed', function (event) {
            place = autocomplete.getPlaces()[0];
            streetadd = place.formatted_address;
            newsadd = streetadd.split(",");

// If the place has a geometry, then present it on a map.
          if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
          } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);  // Why 17? Because it looks good.
          }

            $("#Latitude").val(place.geometry.location.lat());
            $("#Longitude").val(place.geometry.location.lng());
            $("#SAddress").val(newsadd[0]);
            
            if (place.address_components) {
                var address_component = place.address_components;
                if (address_component[0].types[0] == "locality") {
                    console.log( ": Third:" + address_component[0].long_name);
                    $("#City").val(address_component[0].long_name);
                }
                if (address_component[0].types[0] == "administrative_area_level_2") {
                    console.log(": Surburb :" + address_component[0].long_name);
                    $("#Surburb").val(address_component[0].long_name);
                }

                if (address_component[0].types[0] == "administrative_area_level_1") {
                    console.log("Region:" + address_component[0].long_name);
                    $("#Region").val(address_component[0].long_name);
                }
                if (address_component[0].types[0] == "post_box") {
                    console.log("PAddress:" + address_component[0].long_name);
                    $("#PAddress").val(address_component[0].long_name);
                }

            }
            clearMarkers();
            addMarker(place.geometry.location);
            geocodePosition(place.geometry.location);
        });

    }




    // Adds a marker to the map and push to the array.
    function addMarker(location) {
        var marker = new google.maps.Marker({
            position: location,
            map: map,
            draggable: false,
            center: location,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
        markers.push(marker);
    }
    function clearMarkers() {
        setMapOnAll(null);
    }
    function setMapOnAll(map) {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(map);
        }
    }



// @docs
// https://darksky.net/dev/docs

// =================================================
// Stagger Fade-In
// =================================================

function staggerFade() {
	setTimeout(function() {
		$('.fadein-stagger > *').each(function() {
			$(this).addClass('js-animated');
		})
	}, 30);
}

// =================================================
// Skycons
// =================================================

    function skycons() {
        var i,
                icons = new Skycons({
                    "color": "#000000",
                    "resizeClear": true // nasty android hack
                }),
                list = [// listing of all possible icons
                    "clear-day",
                    "clear-night",
                    "partly-cloudy-day",
                    "partly-cloudy-night",
                    "cloudy",
                    "rain",
                    "sleet",
                    "snow",
                    "wind",
                    "fog"
                ];

        // loop thru icon list array
        for (i = list.length; i--; ) {
            var weatherType = list[i], // select each icon from list array
                    // icons will have the name in the array above attached to the
                    // canvas element as a class so let's hook into them.
                    elements = document.getElementsByClassName(weatherType);

            // loop thru the elements now and set them up
            for (e = elements.length; e--; ) {
                icons.set(elements[e], weatherType);
            }
        }

        // animate the icons
        icons.play();
    }
</script>
<script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCBkV4Yn4LxCaVECMWyMFi-robcivGseiI&callback=initMap&libraries=places">
</script>
